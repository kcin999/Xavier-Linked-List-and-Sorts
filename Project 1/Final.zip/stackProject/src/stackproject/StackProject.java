/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackproject;

/**
 *
 * @author nbier
 */
public class StackProject {
    
    Node top = null;
    
    //Default Constructer
    
    public void push(char item){
     Node temp = new Node(item, top);   
     top = temp;
    }
    
    
    public char pop() throws Exception{
        if(top == null){
            throw new Exception();
        }
        char item = top.value;
        top = top.next;
        return item;
    }
    private class Node{
        public char value;
        public Node next;
        
        public Node(char value, Node next){
            this.value = value;
            this.next = next;
        }
    }
    public static void main(String[] args) throws Exception {
        StackProject stack = new StackProject();
        char item = 'a';
        for (int i =0;i<10;i++){
            stack.push(item);
            item++;
        }
        
        for(int i =0;i<10;i++){
            System.out.println(stack.pop());
        }
    }
    
}
